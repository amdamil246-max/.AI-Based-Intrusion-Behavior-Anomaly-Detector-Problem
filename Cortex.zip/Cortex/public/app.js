// CORTEX X: CLIENT LOGIC

const STATE = {
    risk: 0.0,
    keys: 0,
    lastDown: Date.now(),
    mouseLast: { x: 0, y: 0, t: 0 },
    locked: false,
    calibrated: false
};

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    generateDeviceHash();
    log("SYSTEM INITIALIZED", "success");
});

// --- API COMMUNICATION ---
async function sendEvent(type, payload = {}) {
    if (STATE.locked) return;

    const body = {
        event_type: type,
        dwell_time: payload.dwell || 0.0,
        mouse_velocity: payload.velocity || 0.0,
        input_text: payload.text || "",
        honeypot_triggered: payload.honey || false
    };

    try {
        const response = await fetch('/api/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        
        const result = await response.json();
        
        // Handle Server Verdict
        if (result.status === "BLOCK") {
            triggerLockdown(result.reason);
        } else if (result.reason) {
            updateRiskVisuals(result.score, result.reason);
        }
    } catch (err) {
        console.error("Brain connection lost", err);
    }
}

// --- SENSOR 1: KEYSTROKE DYNAMICS ---
['inp-user', 'inp-pass', 'inp-terminal'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;

    el.addEventListener('keydown', () => STATE.lastDown = Date.now());
    
    el.addEventListener('keyup', (e) => {
        const dwell = Date.now() - STATE.lastDown;
        STATE.keys++;

        // Visual Feedback
        document.getElementById('val-dwell').innerText = `${dwell} ms`;
        document.getElementById('bar-dwell').style.width = `${Math.min(dwell, 200) / 2}%`;

        // Mood Calibration (Client Side Visuals)
        if (!STATE.calibrated) {
            const pct = (STATE.keys / 10) * 100;
            document.getElementById('bar-mood').style.width = `${pct}%`;
            if (STATE.keys >= 10) {
                STATE.calibrated = true;
                const moodLabel = document.getElementById('val-mood');
                moodLabel.innerText = "VERIFIED";
                moodLabel.className = "text-emerald-500 font-bold";
                log("MOOD CALIBRATION COMPLETE", "success");
            }
        }

        // Send to Backend
        sendEvent('keystroke', { 
            dwell: dwell, 
            text: e.target.value 
        });
    });
});

// --- SENSOR 2: MOUSE TELEMETRY ---
document.addEventListener('mousemove', (e) => {
    if (STATE.locked) return;

    // Visual Trail
    const dot = document.createElement('div');
    dot.className = 'trail-dot';
    dot.style.left = `${e.clientX}px`;
    dot.style.top = `${e.clientY}px`;
    document.getElementById('mouse-layer').appendChild(dot);
    setTimeout(() => { dot.style.opacity = 0; setTimeout(() => dot.remove(), 500); }, 100);

    // Velocity Calculation
    const now = Date.now();
    const dt = now - STATE.mouseLast.t;
    
    if (dt > 100) { // Limit sampling rate to avoid network spam
        const dist = Math.hypot(e.clientX - STATE.mouseLast.x, e.clientY - STATE.mouseLast.y);
        const velocity = dist / dt; // pixels per ms
        
        if (velocity > 5) { // Only send suspicious movements
            sendEvent('mouse', { velocity: velocity });
        }
        STATE.mouseLast = { x: e.clientX, y: e.clientY, t: now };
    }
});

// --- SENSOR 3: FORENSICS (Focus & Paste) ---
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        highlightFlag("flag-focus");
        sendEvent('focus_loss');
    }
});

document.addEventListener('paste', () => {
    highlightFlag("flag-paste");
    sendEvent('paste');
});

// --- SENSOR 4: HONEYPOTS ---
// 1. Invisible Input Trap
document.getElementById('btn-login').addEventListener('click', () => {
    const honeyVal = document.getElementById('honey_ghost').value;
    if (honeyVal !== "") {
        sendEvent('honeypot', { honey: true });
        return;
    }
    
    // Simulate Login Success for demo
    document.getElementById('view-login').classList.add('hidden');
    const term = document.getElementById('view-terminal');
    term.classList.remove('hidden');
    term.classList.add('flex');
    log("USER AUTHENTICATED", "success");
});

// 2. Fake File Trap
document.getElementById('honey-file').addEventListener('click', () => {
    sendEvent('honeypot', { honey: true });
});


// --- UTILITIES & VISUALS ---

function updateRiskVisuals(increment, reason) {
    STATE.risk = Math.min(10.0, STATE.risk + increment);
    const elRisk = document.getElementById('risk-score');
    const elLabel = document.getElementById('risk-label');
    
    elRisk.innerText = STATE.risk.toFixed(1);

    if (STATE.risk > 8.5) {
        elRisk.classList.replace('text-yellow-500', 'text-red-500');
        elRisk.classList.replace('text-emerald-500', 'text-red-500');
        elLabel.innerText = "CRITICAL";
        elLabel.className = "text-[10px] font-bold text-red-500 bg-red-900/20 px-2 rounded inline-block";
    } else if (STATE.risk > 4.0) {
        elRisk.classList.replace('text-emerald-500', 'text-yellow-500');
        elLabel.innerText = "SUSPICIOUS";
        elLabel.className = "text-[10px] font-bold text-yellow-500 bg-yellow-900/20 px-2 rounded inline-block";
    }

    if(increment > 0) log(`RISK +${increment}: ${reason}`, "warning");
}

function triggerLockdown(reason) {
    STATE.locked = true;
    const lockScreen = document.getElementById('lock-screen');
    lockScreen.classList.remove('hidden');
    lockScreen.classList.add('flex');
    document.getElementById('lock-reason').innerText = reason;
    log(`⛔ LOCKDOWN: ${reason}`, "error");
}

function generateDeviceHash() {
    setTimeout(() => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        ctx.textBaseline = "top";
        ctx.font = "14px 'Arial'";
        ctx.fillStyle = "#f60";
        ctx.fillRect(125, 1, 62, 20);
        ctx.fillStyle = "#069";
        ctx.fillText("CortexX_Fingerprint", 2, 15);
        
        const b64 = canvas.toDataURL().replace("data:image/png;base64,", "");
        const bin = atob(b64);
        let crc = -1;
        for (let i = 0; i < bin.length; i++) {
            crc = (crc >>> 8) ^ crcTable[(crc ^ bin.charCodeAt(i)) & 0xFF];
        }
        
        const hash = (crc >>> 0).toString(16).toUpperCase();
        document.getElementById('gpu-hash').innerText = `0x${hash}`;
    }, 500);
}

// CRC Table for hashing (simplified)
const crcTable = (function() {
    let c;
    const table = [];
    for(let n =0; n < 256; n++){
        c = n;
        for(let k =0; k < 8; k++){
            c = ((c&1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
        }
        table[n] = c;
    }
    return table;
})();

function highlightFlag(id) {
    const el = document.getElementById(id);
    el.classList.remove('bg-gray-800', 'text-gray-600');
    el.classList.add('bg-red-900', 'text-red-500', 'border-red-700');
}

function log(msg, type) {
    const elLogs = document.getElementById('console-logs');
    const div = document.createElement('div');
    const t = new Date().toLocaleTimeString();
    let c = "text-gray-500";
    if (type === "error") c = "text-red-500 font-bold";
    if (type === "warning") c = "text-yellow-500";
    if (type === "success") c = "text-emerald-500";
    
    div.innerHTML = `<span class="opacity-30">[${t}]</span> <span class="${c}">${msg}</span>`;
    elLogs.prepend(div);
}